﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFinalPD.Builder
{
    public class AccesoEstandar : AccesoAreasLudicas
    {
        public string DetalleAcceso()
        {
            return "1 vez al día: piscina, juegos infantiles";
        }
    }
}
