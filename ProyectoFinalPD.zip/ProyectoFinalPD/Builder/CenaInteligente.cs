﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFinalPD.Builder
{
    public class CenaInteligente : ServicioCena
    {
        public string DetalleServicioCena()
        {
            return "Rodizio del menú + refresco ilimitado + servicio a habitación gratis";
        }
    }
}
