﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFinalPD.Builder
{
    public class DesayunoInteligente : Desayuno
    {
        public string DetalleDesayuno()
        {
            return "Un refresco, un jugo, frutas, pan, galletas, ración de alimento cocinado, alimento fitness";
        }
    }
}
